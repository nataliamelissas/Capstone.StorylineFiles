function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ralPXG9fvK":
        Script1();
        break;
      case "5rNV8ucXTab":
        Script2();
        break;
      case "5faGP8VT6au":
        Script3();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
