function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6MP8zVEQ9BX":
        Script1();
        break;
      case "5l329HunyGf":
        Script2();
        break;
      case "6NRmu5hRGXB":
        Script3();
        break;
      case "5WooVjEwDvD":
        Script4();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
