function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6JAEXEOkunD":
        Script1();
        break;
      case "637o367ZQvt":
        Script2();
        break;
      case "6G6eN0VHE89":
        Script3();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
