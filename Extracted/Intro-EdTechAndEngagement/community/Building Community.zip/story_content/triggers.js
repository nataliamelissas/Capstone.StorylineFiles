function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6GYoAQ7gm4Z":
        Script1();
        break;
      case "5a7wSoKdNC7":
        Script2();
        break;
      case "64Jo0PXaJ0t":
        Script3();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
