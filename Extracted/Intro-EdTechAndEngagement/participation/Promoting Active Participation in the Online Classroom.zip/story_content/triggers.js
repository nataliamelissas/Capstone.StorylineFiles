function ExecuteScript(strId)
{
  switch (strId)
  {
      case "67CAQNYTtFy":
        Script1();
        break;
      case "5qGEbu4wlpS":
        Script2();
        break;
      case "6jjtq0P8Mmn":
        Script3();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
