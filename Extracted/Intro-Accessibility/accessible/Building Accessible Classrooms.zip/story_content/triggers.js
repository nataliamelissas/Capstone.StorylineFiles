function ExecuteScript(strId)
{
  switch (strId)
  {
      case "69dfXjv2MUQ":
        Script1();
        break;
      case "6XruwcNDFYd":
        Script2();
        break;
      case "6fmMVGdvCMQ":
        Script3();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
