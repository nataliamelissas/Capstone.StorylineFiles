function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5iV0gmcJWFi":
        Script1();
        break;
      case "67NQmexxipg":
        Script2();
        break;
      case "6D6dx86Fr5L":
        Script3();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
