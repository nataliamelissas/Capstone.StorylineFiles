function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6SIB5pAvEPt":
        Script1();
        break;
      case "6oPWq7a6b4u":
        Script2();
        break;
      case "6cejpLZZT3o":
        Script3();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
