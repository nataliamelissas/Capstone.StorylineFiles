function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ezdoHs8TLn":
        Script1();
        break;
      case "6ecVR8adwrm":
        Script2();
        break;
      case "5tctWpnjhDI":
        Script3();
        break;
      case "5ZctriNc7Em":
        Script4();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
