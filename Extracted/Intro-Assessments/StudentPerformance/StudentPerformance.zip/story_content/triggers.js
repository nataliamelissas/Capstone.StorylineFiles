function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6jVctefRcNf":
        Script1();
        break;
      case "5bOwBzK1mzh":
        Script2();
        break;
      case "5wSvc72g6Uy":
        Script3();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
