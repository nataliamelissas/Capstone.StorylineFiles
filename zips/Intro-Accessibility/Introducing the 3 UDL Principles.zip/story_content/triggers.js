function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6EwaX1UVtdq":
        Script1();
        break;
      case "5tWFnkkoXCn":
        Script2();
        break;
      case "5nGs8qGP0mi":
        Script3();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
