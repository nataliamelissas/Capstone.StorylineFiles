function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Liavlzm5U2":
        Script1();
        break;
      case "6OkXpr47S9b":
        Script2();
        break;
      case "5Uqol2XU2fJ":
        Script3();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
