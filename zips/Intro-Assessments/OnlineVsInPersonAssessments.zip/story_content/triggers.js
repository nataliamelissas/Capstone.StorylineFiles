function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6GS3rWmOleu":
        Script1();
        break;
      case "6FFnpeTZ5bW":
        Script2();
        break;
      case "6mxzJdvAoAI":
        Script3();
        break;
      case "6djQ5AtlL8p":
        Script4();
        break;
      case "6FTqWPs1LKA":
        Script5();
        break;
      case "5xlfdZjxa22":
        Script6();
        break;
      case "6oN77XbAAFT":
        Script7();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
