function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6UjdS80kSHa":
        Script1();
        break;
      case "6P57JAVcpJE":
        Script2();
        break;
      case "6guPLMqb6h5":
        Script3();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
