function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5n9acvjW4q7":
        Script1();
        break;
      case "5plvhbcp0T5":
        Script2();
        break;
      case "5wanV9XG8zP":
        Script3();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
