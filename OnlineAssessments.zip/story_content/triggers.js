function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6MgyQ4t8uYY":
        Script1();
        break;
      case "6G9DNdtVVqP":
        Script2();
        break;
      case "5cvmGpCPNmL":
        Script3();
        break;
      case "5Vf8ej0a6at":
        Script4();
        break;
      case "6dwOkQelJUW":
        Script5();
        break;
      case "67CEstUjJxU":
        Script6();
        break;
      case "6piS1RXRWtX":
        Script7();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
};
